<!DOCTYPE html>
<html>
<head>
    <title>Detalle del Producto</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('css/styles.css') ?>">
</head>
<body>
    <div class="container">
        <div class="producto-detalle">
            <h1><?= esc($producto['nombre']) ?></h1>
            <p><strong>Precio:</strong> $<?= esc($producto['precio']) ?></p>
            <p><strong>Stock:</strong> <?= esc($producto['stock']) ?></p>
            <p><strong>Código:</strong> <?= esc($producto['codigo']) ?></p>
            <a href="<?= base_url('/') ?>">Volver al listado</a>
        </div>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <title>Listado de Productos</title>
    <link rel="stylesheet" type="text/css" href="<?= base_url('css/styles.css') ?>">
</head>
<body>
    <div class="container">
        <h1>Listado de Productos</h1>
        <ul>
            <?php foreach ($productos as $producto): ?>
                <li>
                    <a href="<?= base_url('producto/' . $producto['id']) ?>">
                        <?= esc($producto['nombre']) ?> - $<?= esc($producto['precio']) ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</body>
</html>
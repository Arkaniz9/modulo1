<?php

namespace App\Controllers;

use App\Models\ProductoModel;

class ProductoController extends BaseController
{
    public function index()
    {
        $productoModel = new ProductoModel();
        $data['productos'] = $productoModel->findAll();

        return view('productos/index', $data);
    }

    public function detalle($id)
    {
        $productoModel = new ProductoModel();
        $data['producto'] = $productoModel->find($id);
    
        if (!$data['producto']) {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    
        return view('productos/detalle', $data);
    }
}

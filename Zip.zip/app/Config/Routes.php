<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'ProductoController::index');
$routes->get('producto/(:num)', 'ProductoController::detalle/$1');